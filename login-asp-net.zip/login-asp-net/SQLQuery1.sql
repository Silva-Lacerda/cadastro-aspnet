SELECT TOP (1000) [Id]
      ,[Nome]
      ,[Rua]
      ,[Bairro]
      ,[dataCadastro]
  FROM [Cadastro].[dbo].[Cadastro]

  SELECT * FROM cadastro;