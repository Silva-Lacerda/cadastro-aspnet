﻿using Cadastro.Data;
using Cadastro.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;
using System.Collections.Generic;

namespace Cadastro.Controllers
{
    public class CadastroController : Controller
    {
        //Passando os registros do banco para dentro da classe CadastroController
            //Já pode usar os métodos do banco, deletar; atualizar; adicionar etc...
            //Injeção de dependência
        readonly private ApplicationDbContext _db;
        public CadastroController(ApplicationDbContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            //Pegando a tabela Cadastro inteira do banco e colocando dentro de cadastro e logo após transformando em IEnumerable
            IEnumerable<CadastroModel> cadastro = _db.Cadastro;

            //Passando os registros do banco para view Index
            return View(cadastro);
        }


        [HttpGet] //GET
        public IActionResult Cadastrar()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Editar(int? id)
        {
            if(id == null || id == 0)
            {
                return NotFound();
            }

            CadastroModel cadastro = _db.Cadastro.FirstOrDefault(x => x.Id == id);

            if (cadastro == null)
            {
                return NotFound();
            }



            return View(cadastro);
        }

        [HttpGet]
        public IActionResult Excluir(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            CadastroModel cadastro = _db.Cadastro.FirstOrDefault(x => x.Id == id);

            if(cadastro == null)
            {
                return NotFound();
            }

            return View(cadastro);

        }




        [HttpPost] //POST Cadastrar: recebe dados do formulário e envia para o Model
        public IActionResult Cadastrar(CadastroModel cadastro)
        {
            if(ModelState.IsValid)
            {
                _db.Cadastro.Add(cadastro); //Entrando no banco e adicionando os dados da model cadastro
                _db.SaveChanges(); //Salvando os dados dentro do banco

                return RedirectToAction("Index"); //Se tudo deu certo, mandar de volta para action Index
            }

            return View(); //Caso de errado, permanece na action atual
        }

        [HttpPost]
        public IActionResult Editar(CadastroModel cadastro)
        {
            if(ModelState.IsValid)
            {
                _db.Cadastro.Update(cadastro);
                _db.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(cadastro);
        }

        [HttpPost]
        public IActionResult Excluir(CadastroModel cadastro)
        {
            if(cadastro == null)
            {
                return NotFound();
            }

            _db.Cadastro.Remove(cadastro);
            _db.SaveChanges();

            return RedirectToAction("Index");
        }

        
    }
}
