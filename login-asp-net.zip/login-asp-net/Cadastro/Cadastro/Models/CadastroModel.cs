﻿using System.ComponentModel.DataAnnotations;

namespace Cadastro.Models
{
    public class CadastroModel
    {
        public int Id { get; set; }

        //Mensagem de erro caso não digite nada na label
        [Required(ErrorMessage = "Digite um nome")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Digite o nome da Rua")]
        public string Rua { get; set; }

        [Required(ErrorMessage = "Digite o nome do Bairro")]
        public string Bairro { get; set; }
        public DateTime dataCadastro { get; set; } = DateTime.Now;
    }
}
